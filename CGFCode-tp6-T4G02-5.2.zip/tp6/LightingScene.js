var degToRad = Math.PI / 180.0;

var BOARD_WIDTH = 6.0;
var BOARD_HEIGHT = 4.0;

var BOARD_A_DIVISIONS = 30;
var BOARD_B_DIVISIONS = 100;

class LightingScene extends CGFscene 
{
	constructor()
	{
		super();
	};
 
	init(application) 
	{

		super.init(application);

		this.initCameras();

	 	this.initLights();
	 	
		this.axisOn=true; 
		//this.option2=false;

		this.speed=3;
		this.light0=true;
		this.light1=true;
		this.light2=true;
		this.light3=true;

		this.gl.clearColor(0, 0.5, 1.0, 1.0);
		this.gl.clearDepth(100.0);
		this.gl.enable(this.gl.DEPTH_TEST);
		this.gl.enable(this.gl.CULL_FACE);
		this.gl.depthFunc(this.gl.LEQUAL);

		this.axis = new CGFaxis(this);
		
		this.vehicleAppearances = new Array();
		this.currVehicleAppearance = 0;

		this.car = new MyVehicle (this);
		this.terrain= new Plane(this,50,0,1,0,1);
		
		this.wPress = false;
		this.sPress = false;
		this.aPress = false;
		this.dPress = false;

		this.enableTextures(true);
		
		this.skyAppearance = new CGFappearance(this);
		this.skyAppearance.loadTexture("../resources/images/blue.png");
		//this.skyAppearance.setTextureWrap('REPEAT','REPEAT');
	
		this.wheelTexture = new CGFappearance (this);
		this.wheelTexture.loadTexture ("../resources/images/wheel.png");

		this.carBlueTexture = new CGFappearance (this);
		this.carBlueTexture.loadTexture ("../resources/images/carBlue.png");

		this.carRainbowTexture = new CGFappearance (this);
		this.carRainbowTexture.loadTexture ("../resources/images/carRainbow.png");

		this.carRedTexture = new CGFappearance (this);
		this.carRedTexture.loadTexture ("../resources/images/carRed.jpg");
		
		this.carGreenTexture = new CGFappearance (this);
		this.carGreenTexture.loadTexture ("../resources/images/carGreen.png");

		this.carYellowTexture = new CGFappearance (this);
		this.carYellowTexture.loadTexture ("../resources/images/carYellow.png");

		this.rimTexture = new CGFappearance (this);
		this.rimTexture.loadTexture ("../resources/images/rim.png");

		this.mirrorTexture = new CGFappearance (this);
		this.mirrorTexture.loadTexture ("../resources/images/mirror.png");
		
		this.stopLampTexture= new CGFappearance(this);
		this.stopLampTexture.loadTexture("../resources/images/stop.png");
		
		this.vehicleAppearances.push (this.carBlueTexture);
		this.vehicleAppearances.push (this.carRainbowTexture);
		this.vehicleAppearances.push (this.carRedTexture);
		this.vehicleAppearances.push (this.carGreenTexture);
		this.vehicleAppearances.push (this.carYellowTexture);

		this.setUpdatePeriod(100);
	};

	initCameras() 
	{
		this.camera = new CGFcamera(0.4, 0.1, 500, vec3.fromValues(30, 30, 30), vec3.fromValues(0, 0, 0));
	};

	initLights() 
	{
		
		this.setGlobalAmbientLight(0,0,0,1);
		
		// Positions for four lights
		
		this.lights[0].setPosition(4, 2, -2, 1);
		this.lights[0].setVisible(true); // show marker on light position (different from enabled)
		this.lights[0].setAmbient(0, 0, 0, 1);
		this.lights[0].setDiffuse(1.0, 1.0, 1.0, 1.0);
		this.lights[0].setSpecular (1,1,0,1);
		this.lights[0].enable();
	

		this.lights[1].setPosition(-5, -1.0, 0, 1.0);
		this.lights[1].setVisible(true); // show marker on light position (different from enabled)
		this.lights[1].setAmbient(0, 0, 0, 1);
		this.lights[1].setDiffuse(1.0, 1.0, 1.0, 1.0);
		this.lights[1].enable();

		this.lights[2].setPosition (0, 1.0, 3.0, 1.0);
		this.lights[2].setVisible(true);
		this.lights[2].setAmbient(0, 0, 0, 1);
		this.lights[2].setDiffuse(1.0, 1.0, 1.0, 1.0);
		this.lights[2].setSpecular (1,1,1,1);
		this.lights[2].setConstantAttenuation(1);
		this.lights[2].setLinearAttenuation (1);
		this.lights[2].setQuadraticAttenuation (0);
		 this.lights[2].enable();

		//this.lights[1].setVisible(true); // show marker on light position (different from enabled)
		this.lights[3].setPosition(0, 6, 0, 1.0);
		this.lights[3].setVisible(true); // show marker on light position (different from enabled)	
	
		this.lights[3].setAmbient(0, 0, 0, 1);
		this.lights[3].setDiffuse(1.0, 1.0, 1.0, 1.0);
/*		this.lights[3].setSpecular (1,1,0,1);
		this.lights[3].setConstantAttenuation(0);
		this.lights[3].setLinearAttenuation (0);
		this.lights[3].setQuadraticAttenuation (1);*/
		this.lights[3].enable();
	};

	updateLights() 
	{
		for (var i = 0; i < this.lights.length; i++)
			this.lights[i].update();
	if (this.light0)
		this.lights[0].enable();
	else
		this.lights[0].disable();
		
	if (this.light1)
		this.lights[1].enable();
	else
		this.lights[1].disable();
	
	if (this.light2)
		this.lights[2].enable();
	else
		this.lights[2].disable();
			
	if (this.light3)
		this.lights[3].enable();
	else
		this.lights[3].disable();
	}

	checkKeys()
	{
		this.wPress = false;
		this.sPress = false;
		this.aPress = false;
		this.dPress = false;
	if (this.gui.isKeyPressed("KeyW"))
	{
		this.wPress = true;
	}
	if (this.gui.isKeyPressed("KeyS"))
	{
		this.sPress = true;
	}
	if (this.gui.isKeyPressed("KeyA"))
	{
		this.aPress = true;
	}
	if (this.gui.isKeyPressed("KeyD"))
		this.dPress=true;
	}



	display() 
	{
		// ---- BEGIN Background, camera and axis setup

		// Clear image and depth buffer everytime we update the scene
		this.gl.viewport(0, 0, this.gl.canvas.width, this.gl.canvas.height);
		this.gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT);

		// Initialize Model-View matrix as identity (no transformation)
		this.updateProjectionMatrix();
		this.loadIdentity();

		// Apply transformations corresponding to the camera position relative to the origin
		this.applyViewMatrix();

		// // Update all lights used
			this.updateLights();
		// Draw axis
		if (this.axisOn)	this.axis.display();

		this.pushMatrix();
		this.translate (0, 0.5, 2);
		this.vehicleAppearances[this.currVehicleAppearance].apply()
		this.car.display();
		this.popMatrix();
		
		this.pushMatrix();
		this.rotate(-90*Math.PI/180.0,1,0,0);
		this.scale(BOARD_WIDTH, BOARD_HEIGHT, 1);	
		this.skyAppearance.apply();
		this.terrain.display();
		this.popMatrix();
		};
	doSomething()
	{ 
		console.log("Doing something..."); 
	}
	update (currentTime)
	{
		this.checkKeys();
		this.car.update(currentTime, this.speed, this.wPress, this.sPress, this.aPress, this.dPress);

	}
};
