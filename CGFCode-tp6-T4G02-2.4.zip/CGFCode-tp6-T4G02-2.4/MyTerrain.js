class MyTerrain extends Plane 
{
    constructor(scene, nrDivs, minS, maxS, minT, maxT) 
	{
		super(scene,nrDivs,minS,maxS,minT,maxT);
	}
   
}